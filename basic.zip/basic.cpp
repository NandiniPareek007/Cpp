#include<iostream>
//using namespace std;
int main ()
{
	std::cout<<"Welcome to c++ programming";
}
